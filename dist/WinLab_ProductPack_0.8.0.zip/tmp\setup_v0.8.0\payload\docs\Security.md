﻿# Security (summary)

## What WinLab does
- Aisla la actividad en Windows Sandbox.
- Copia archivos desde carpeta ReadOnly a una carpeta interna antes de escanear.
- Actualiza firmas de Microsoft Defender (si hay red) y ejecuta escaneo.
- Recolecta evidencia: hashes, MOTW, Authenticode, detecciones, analisis de URL.
- Genera reportes HTML/JSON/TXT con recomendacion y AutoDecision (heuristica).

## What WinLab does NOT do
- No es un antivirus propio ni garantiza deteccion total.
- No reemplaza a un SOC/servicio profesional de analisis.

## Presets y tradeoffs
- UltraSecure: sin red, maxima reduccion de superficie.
- Balanced: red habilitada solo para update/triage (InternetOnly).
- Networked: red menos restrictiva; usar solo para URLs sospechosas.

## Residual risks
- 0-day y tecnicas de evasion (posibles falsos negativos/positivos).
- Escape de Sandbox (raro pero posible).
- Con red habilitada existe riesgo de exfiltracion.

## Hardening aplicado
- Clipboard/printer/audio/video deshabilitados.
- ProtectedClient habilitado.
- Outbox solo para reportes.
