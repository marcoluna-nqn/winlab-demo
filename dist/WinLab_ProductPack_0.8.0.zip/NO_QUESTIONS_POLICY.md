# Política: No preguntar / avanzar con criterio

- Avanzar con defaults seguros.
- No pedir confirmación salvo que una acción sea irreversible (borrar assets existentes, reescritura masiva).
- Si falta un dato crítico, elegir la alternativa más segura y documentar el supuesto en el commit.
