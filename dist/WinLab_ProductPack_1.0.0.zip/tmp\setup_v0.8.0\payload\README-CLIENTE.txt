﻿WinLab (Windows Sandbox) - Instalación
=====================================

Versión: 1.0.0

OBJETIVO
- Analizar archivos o URLs sospechosas sin tocar el host.
- Actualizar firmas de Microsoft Defender y generar un reporte claro.

USO RAPIDO
- Ejecuta WinLab_Launcher.cmd y elegi el perfil.
- Podés arrastrar y soltar un archivo o pegar una URL.

PERFILES
- Equilibrado (10 min): red limitada + firewall InternetOnly + outbox activo.
- Ultra seguro (5 min): sin red + máximo aislamiento.
- Con red (15 min): pensado para URLs con red habilitada.

MODO TERMINAL (opcional)
- En la carpeta instalada (%LOCALAPPDATA%\Programs\WinLab\):
  - WinLab.ps1 help
  - WinLab.ps1 scan -Path "C:\ruta\archivo.ext" -Preset UltraSecure
  - WinLab.ps1 url  -Url "https://ejemplo" -Preset Networked

REPORTES
- Lanzador: C:\WinLab_Outbox\run_YYYYMMDD_HHMMSS_*
- CLI: %LOCALAPPDATA%\WinLab\outbox\run_YYYYMMDD_HHMMSS_*

LOGS (host)
- C:\WinLab\logs\

REQUISITOS
- Windows 10/11 Pro / Enterprise / Education
- Windows Sandbox habilitado (Containers-DisposableClientVM)
- Virtualización habilitada en BIOS/UEFI

NOTA
WinLab no es un antivirus propio. El motor es Microsoft Defender.

