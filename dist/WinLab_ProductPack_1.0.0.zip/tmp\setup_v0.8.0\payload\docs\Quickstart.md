﻿# WinLab (Installer Edition)

Version: 0.8.0

## Requisitos
- Windows 10/11 Pro / Enterprise / Education
- Windows Sandbox habilitado (Containers-DisposableClientVM)
- Virtualizacion habilitada en BIOS/UEFI

## Presets
- **Balanced** (10 min): red habilitada con firewall InternetOnly, outbox ON.
- **UltraSecure** (5 min): sin red, puentes cerrados, outbox ON (maximo aislamiento).
- **Networked** (15 min): red habilitada con reglas menos restrictivas, pensado para URLs (usar con criterio).

## Uso rapido (accesos directos)
1. Deja el archivo a analizar en Descargas.
2. Ejecuta el acceso directo correspondiente.
3. Espera a que el Sandbox se cierre.
4. Abre el reporte en outbox.

## CLI (opcional)
Desde la carpeta instalada: %LOCALAPPDATA%\Programs\WinLab\

- WinLab.ps1 scan -Path "C:\ruta\archivo.ext" -Preset UltraSecure -OpenOutbox
- WinLab.ps1 url -Url "https://sitio.ejemplo" -Preset Networked -OpenOutbox
- WinLab.ps1 session -Url "https://sitio.ejemplo" (alias)
- WinLab.ps1 analyze-url / scan-file (aliases)

## Reportes
- Outbox: %LOCALAPPDATA%\WinLab\outbox\run_YYYYMMDD_HHMMSS_*
- Logs:   %LOCALAPPDATA%\WinLab\logs\

## Nota
WinLab no es un antivirus propio. Usa Microsoft Defender dentro de Windows Sandbox y agrega aislamiento, pipeline y reporte.
