﻿// Configuración de WinLab Security.
window.WINLAB_CONFIG = {
  BASE_URL: "https://winlab-security.github.io/winlab/",
  APP_VERSION: "1.0.0",
  BUY_MP_URL: "",
  BUY_STRIPE_URL: "",
  WHATSAPP_URL: "https://wa.me/5492996209136?text=Hola%20WinLab%20Security"
};
