// WinLab purchase links (edit as needed).
// If BUY_* is empty, buttons fall back to WHATSAPP_URL.
window.WINLAB_CONFIG = {
  BUY_MP_URL: "", // Pega aqui el link real de MercadoPago.
  BUY_STRIPE_URL: "", // Pega aqui el link real de Stripe.
  WHATSAPP_URL: "https://wa.me/5492996209136?text=Hola%20quiero%20WinLab"
};
