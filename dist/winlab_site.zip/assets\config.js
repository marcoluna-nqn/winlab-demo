// WinLab purchase links (edit as needed).
// If BUY_* is empty, buttons fall back to WHATSAPP_URL.
window.WINLAB_CONFIG = {
  BUY_MP_URL: "",
  BUY_STRIPE_URL: "",
  WHATSAPP_URL: "https://wa.me/5490000000000?text=Hola%20WinLab%20-%20Quiero%20comprar"
};
