﻿WIN-LAB (Windows Sandbox) - Instalador
======================================

Version: 0.8.0

OBJETIVO
- Abrir Windows Sandbox para analizar archivos sospechosos sin tocar el host.
- Actualizar firmas de Microsoft Defender y generar un reporte claro.

PRESETS
- Balanced (10 min): red habilitada + firewall InternetOnly + outbox ON (por defecto).
- UltraSecure (5 min): sin red + puentes cerrados + outbox ON (maximo aislamiento).
- Networked (15 min): para URLs sospechosas; red habilitada y reporte con triage de URL (usar con criterio).

MODO TERMINAL (opcional)
- En la carpeta instalada (%LOCALAPPDATA%\Programs\WinLab\):
  - WinLab.ps1 help
  - WinLab.ps1 scan -Path "C:\ruta\archivo.ext" -Preset UltraSecure
  - WinLab.ps1 url  -Url "https://ejemplo" -Preset Networked

REPORTES (cuando outbox esta ON)
- %LOCALAPPDATA%\WinLab\outbox\run_YYYYMMDD_HHMMSS_*

LOGS (host)
- %LOCALAPPDATA%\WinLab\logs\

REQUISITOS
- Windows 10/11 Pro / Enterprise / Education
- Windows Sandbox habilitado (Containers-DisposableClientVM)
- Virtualizacion habilitada en BIOS/UEFI

NOTA
WinLab no es un antivirus propio. El motor es Microsoft Defender.

