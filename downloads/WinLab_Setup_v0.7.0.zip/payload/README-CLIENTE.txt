WIN-LAB (Windows Sandbox) - Instalador
=====================================

Version: 0.7.0

OBJETIVO
- Abrís Windows Sandbox para navegar/descargar y evaluar archivos sospechosos.
- Tras X minutos, el Sandbox se apaga y se descarta (no queda nada).
- Dentro del Sandbox usa Microsoft Defender + señales anti-estafa (score + razones).

PRESSETS
- Balanced (10 min): red habilitada + firewall InternetOnly + outbox ON (por defecto)
- UltraSecure (5 min): sin red + puentes cerrados + outbox ON (reporte local)
- Networked (15 min): para abrir links sospechosos; red habilitada y reporte con triage de URL (usar con criterio)

MODO TERMINAL (opcional)
- En la carpeta instalada (%LOCALAPPDATA%\Programs\WinLab\):
  - WinLab.ps1 help
  - WinLab.ps1 scan -Path "C:\\ruta\\archivo.ext" -Preset UltraSecure
  - WinLab.ps1 url  -Url "https://ejemplo" -Preset Networked

REPORTES (cuando outbox esta ON)
- Se guardan en:
  %LOCALAPPDATA%\WinLab\outbox\run_YYYYMMDD_HHMMSS\

LOGS (host)
- Para diagnosticar problemas de lanzamiento:
  %LOCALAPPDATA%\WinLab\logs\

REQUISITOS
- Windows 10/11 Pro / Enterprise / Education
- Windows Sandbox habilitado (feature: Containers-DisposableClientVM)
- Virtualización habilitada en BIOS/UEFI

NOTA
Esto NO compite con un antivirus. El motor es Microsoft Defender: WinLab lo envuelve con aislamiento, flujo y reporte.
