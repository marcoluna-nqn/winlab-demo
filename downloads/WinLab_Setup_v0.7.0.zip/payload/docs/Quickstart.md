# WinLab (Installer Edition)

Version: 0.7.0

## Presets
- **Balanced** (recomendado): 10 min, red habilitada pero acotada (DNS/HTTP/HTTPS), outbox ON.
- **UltraSecure**: 5 min, sin red, outbox ON. Máximo aislamiento.
- **Networked**: 15 min, red habilitada (menos restrictiva), outbox ON. Orientado a links sospechosos.

> Nota: "Secure" y "Relaxed" se mantienen solo por compatibilidad (mapean a Balanced/Networked).

## Modos de uso

### 1) "Un click" (accesos directos)
1. Dejá el archivo a analizar en **Descargas** (WinLab toma el más reciente).
2. Ejecutá el acceso directo (Balanced/UltraSecure/Networked).
3. Abrí el reporte en outbox.

### 2) Terminal (CLI)
Desde la carpeta instalada (por defecto: `%LOCALAPPDATA%\Programs\WinLab`):

```powershell
./WinLab.ps1 scan -Path "$env:USERPROFILE\Downloads\archivo.exe" -Preset UltraSecure
./WinLab.ps1 url -Url "https://sitio.ejemplo" -Preset Networked
```

## Reportes
- Outbox (host): `%LOCALAPPDATA%\WinLab\outbox\run_YYYYMMDD_HHMMSS_*\`
- Logs (host): `%LOCALAPPDATA%\WinLab\logs\`
