# Seguridad (resumen)

## Qué hace WinLab
- **Aisla** la actividad en Windows Sandbox y **automatiza** el pipeline:
  - Actualizar firmas de Microsoft Defender (si hay conectividad).
  - Escaneo de archivos en carpeta de trabajo interna.
  - Recolección de evidencias (detecciones, hashes, firmas, MOTW).
  - Reporte HTML/JSON vendible.

## Qué NO hace
- No es un “antivirus propio”. El motor es **Microsoft Defender**.
- No promete 100% de detección (0‑days y evasión existen).

## Puentes y superficie
- Por defecto se deshabilitan: clipboard, printer, audio, video.
- **UltraSecure**: sin red (máximo aislamiento).
- **Balanced**: red habilitada pero acotada (DNS/HTTP/HTTPS) para actualización y triage básico.
- **Networked**: red habilitada con menos restricciones, orientado a links (más riesgoso).

## Riesgos residuales
- Escape de Sandbox (raro pero posible): mitigación parcial, no eliminación.
- Con red habilitada: riesgo de exfiltración (mitigado por firewall y duración limitada).
- Falsos negativos/positivos: interpretar el reporte como **orientación**, no como veredicto absoluto.
